# Fire Client v1.0

Starter Android companion app for Minecraft Bedrock.

## Build on GitHub using an Android phone
1. Create a new GitHub repository named `FireClient`.
2. Upload all files and folders from this ZIP, keeping the folder structure.
3. Open the repository's **Actions** tab.
4. Select **Build Fire Client APK** and tap **Run workflow** (or push to `main`).
5. When the workflow finishes, open the run and download the `Fire-Client-v1.0-debug` artifact.
6. Extract the artifact ZIP to get `app-debug.apk`.

## Build locally
Requires JDK 17 and Gradle 8.9+:
`gradle :app:assembleDebug`

## Notes
- The Play button launches the installed Minecraft Bedrock app using its Android package name.
- This project does not include Minecraft game files, bypass licensing, or provide pirated access.
- Content management and in-game control integration are placeholders for future development.
- This is a starter project; it has not been built or tested on your device yet.
