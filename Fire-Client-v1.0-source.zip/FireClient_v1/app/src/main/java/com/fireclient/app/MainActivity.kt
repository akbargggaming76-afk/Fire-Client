package com.fireclient.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101014)
private val Panel = Color(0xFF1C1C23)
private val Orange = Color(0xFFFF6A24)
private val Red = Color(0xFFE94335)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FireClientApp() }
    }
}

@Composable
fun FireClientApp() {
    var page by remember { mutableStateOf("Home") }
    val context = LocalContext.current
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Orange,
        secondary = Red, onBackground = Color.White, onSurface = Color.White
    )) {
        Row(Modifier.fillMaxSize().background(Bg)) {
            Column(
                Modifier.width(82.dp).fillMaxHeight().background(Color(0xFF17171D))
                    .padding(vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(22.dp)
            ) {
                Text("🔥", fontSize = 30.sp)
                NavIcon(Icons.Default.Home, "Home", page) { page = it }
                NavIcon(Icons.Default.Extension, "Content", page) { page = it }
                NavIcon(Icons.Default.Gamepad, "Controls", page) { page = it }
                NavIcon(Icons.Default.Settings, "Settings", page) { page = it }
            }
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text("FIRE CLIENT", color = Orange, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(page, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                when (page) {
                    "Home" -> {
                        Box(
                            Modifier.fillMaxWidth().height(190.dp)
                                .background(Brush.linearGradient(listOf(Color(0xFF64251D), Color(0xFF25212A))), RoundedCornerShape(22.dp))
                                .padding(20.dp),
                            contentAlignment = Alignment.BottomStart
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("YOUR BEDROCK COMPANION", color = Color.LightGray, fontSize = 11.sp)
                                Text("Ready to play?", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Button(
                            onClick = {
                                val launch = context.packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                                if (launch != null) context.startActivity(launch)
                                else Toast.makeText(context, "Minecraft Bedrock belum terpasang.", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier.fillMaxWidth().height(58.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Orange),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("MAIN MINECRAFT", fontWeight = FontWeight.Bold)
                        }
                        InfoCard("Minecraft Bedrock", "Fire Client membuka aplikasi Minecraft yang terpasang di perangkat.")
                        InfoCard("Quick Access", "Kelola konten dan sesuaikan preferensi client dari menu di samping.")
                    }
                    "Content" -> {
                        InfoCard("Manage Content", "Tempat untuk mengatur resource pack dan addon. Pengelolaan file perlu izin dan pemilihan folder dari Android.")
                        InfoCard("Catatan", "Versi 1.0 ini belum memasang atau mengunduh addon secara otomatis.")
                    }
                    "Controls" -> {
                        InfoCard("Custom Controls", "Pengaturan kontrol lanjutan akan ditambahkan pada pembaruan berikutnya.")
                        InfoCard("Tip", "Kontrol dalam game tetap dapat diubah melalui pengaturan Minecraft.")
                    }
                    else -> {
                        var graphics by remember { mutableStateOf("Fancy") }
                        var sensitivity by remember { mutableFloatStateOf(50f) }
                        InfoCard("Graphics preference", "Preferensi ini disimpan sementara di layar client; belum mengubah pengaturan internal Minecraft.")
                        Text("Graphics", color = Color.LightGray)
                        listOf("Fast", "Fancy", "Deferred").forEach { option ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = graphics == option, onClick = { graphics = option }, colors = RadioButtonDefaults.colors(selectedColor = Orange))
                                Text(option)
                            }
                        }
                        Text("Sensitivity: ${sensitivity.toInt()}%")
                        Slider(value = sensitivity, onValueChange = { sensitivity = it }, valueRange = 0f..100f, colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange))
                    }
                }
                Text("FIRE CLIENT 1.0 • ANDROID", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun NavIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: String, onSelect: (String) -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onSelect(label) }.padding(4.dp)
    ) {
        Icon(icon, contentDescription = label, tint = if (selected == label) Orange else Color.Gray, modifier = Modifier.size(25.dp))
        Text(label, color = if (selected == label) Orange else Color.Gray, fontSize = 9.sp)
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(17.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(body, color = Color.LightGray, fontSize = 13.sp, lineHeight = 19.sp)
    }
}
